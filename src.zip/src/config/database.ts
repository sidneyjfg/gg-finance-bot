import { prisma } from "../infra/prisma";

export const database = prisma;
